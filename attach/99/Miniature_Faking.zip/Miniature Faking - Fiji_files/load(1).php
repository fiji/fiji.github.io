<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns='http://www.w3.org/1999/xhtml' lang='en'>
	<head>
		<title>MediaWiki 1.20alpha</title>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
		<style type='text/css' media='screen'>
			html, body {
				color: #000;
				background-color: #fff;
				font-family: sans-serif;
				text-align: center;
			}

			h1 {
				font-size: 150%;
			}
		</style>
	</head>
	<body>
		<img src="/mediawiki/phase3/skins/common/images/mediawiki.png" alt='The MediaWiki logo' />

		<h1>MediaWiki 1.20alpha</h1>
		<div class='error'>
		<p>LocalSettings.php not found.</p>
		<p>
		Please <a href="/mediawiki/phase3/mw-config/index.php"> set up the wiki</a> first.		</p>

		</div>
	</body>
</html>
